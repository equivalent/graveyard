-- phpMyAdmin SQL Dump
-- version 2.6.1
-- http://www.phpmyadmin.net
-- 
-- Hostiteľ: localhost
-- Vygenerované:: 06.Apr, 2007 - 05:04
-- Verzia serveru: 4.1.9
-- Verzia PHP: 4.3.10
-- 
-- Databáza: `tomas_valent_4d`
-- 

-- --------------------------------------------------------

-- 
-- Štruktúra tabuľky pre tabuľku `admin_nast`
-- 

CREATE TABLE `admin_nast` (
  `id` mediumint(9) NOT NULL auto_increment,
  `zlsi` tinyint(4) NOT NULL default '0',
  `reg_form` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Sťahujem dáta pre tabuľku `admin_nast`
-- 

INSERT INTO `admin_nast` VALUES (1, 0, 'Èlánky su a budú dostupné pre každého');

-- --------------------------------------------------------

-- 
-- Štruktúra tabuľky pre tabuľku `autor_b`
-- 

CREATE TABLE `autor_b` (
  `id_usera` int(11) NOT NULL default '0',
  `id_bufferu` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id_usera`,`id_bufferu`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Sťahujem dáta pre tabuľku `autor_b`
-- 

INSERT INTO `autor_b` VALUES (1, 87860108);
INSERT INTO `autor_b` VALUES (1, 190002442);
INSERT INTO `autor_b` VALUES (1, 511383057);

-- --------------------------------------------------------

-- 
-- Štruktúra tabuľky pre tabuľku `autor_c`
-- 

CREATE TABLE `autor_c` (
  `id_usera` int(11) NOT NULL default '0',
  `id_clanku` int(11) NOT NULL default '0',
  `ack` tinyint(4) NOT NULL default '0',
  `new` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`id_usera`,`id_clanku`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Sťahujem dáta pre tabuľku `autor_c`
-- 

INSERT INTO `autor_c` VALUES (1, 1, 1, 0);
INSERT INTO `autor_c` VALUES (1, 2, 1, 0);
INSERT INTO `autor_c` VALUES (1, 3, 1, 0);
INSERT INTO `autor_c` VALUES (1, 4, 1, 0);
INSERT INTO `autor_c` VALUES (1, 5, 1, 0);

-- --------------------------------------------------------

-- 
-- Štruktúra tabuľky pre tabuľku `autor_o`
-- 

CREATE TABLE `autor_o` (
  `id_usera` int(11) NOT NULL default '0',
  `id_obr` int(11) NOT NULL default '0',
  `new` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`id_usera`,`id_obr`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Sťahujem dáta pre tabuľku `autor_o`
-- 

INSERT INTO `autor_o` VALUES (1, 1, 0);
INSERT INTO `autor_o` VALUES (1, 3, 0);
INSERT INTO `autor_o` VALUES (1, 4, 0);
INSERT INTO `autor_o` VALUES (1, 5, 0);
INSERT INTO `autor_o` VALUES (1, 6, 0);
INSERT INTO `autor_o` VALUES (1, 8, 0);
INSERT INTO `autor_o` VALUES (1, 10, 0);
INSERT INTO `autor_o` VALUES (1, 11, 0);
INSERT INTO `autor_o` VALUES (1, 12, 0);
INSERT INTO `autor_o` VALUES (1, 13, 0);

-- --------------------------------------------------------

-- 
-- Štruktúra tabuľky pre tabuľku `autor_v`
-- 

CREATE TABLE `autor_v` (
  `id_usera` int(11) NOT NULL default '0',
  `id_expl` int(11) NOT NULL default '0',
  `new` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`id_usera`,`id_expl`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Sťahujem dáta pre tabuľku `autor_v`
-- 

INSERT INTO `autor_v` VALUES (1, 1, 0);
INSERT INTO `autor_v` VALUES (1, 2, 0);
INSERT INTO `autor_v` VALUES (1, 3, 0);
INSERT INTO `autor_v` VALUES (1, 4, 0);
INSERT INTO `autor_v` VALUES (1, 5, 0);
INSERT INTO `autor_v` VALUES (1, 6, 0);
INSERT INTO `autor_v` VALUES (1, 7, 0);
INSERT INTO `autor_v` VALUES (1, 8, 0);
INSERT INTO `autor_v` VALUES (1, 9, 0);
INSERT INTO `autor_v` VALUES (1, 10, 0);
INSERT INTO `autor_v` VALUES (1, 11, 0);
INSERT INTO `autor_v` VALUES (1, 12, 0);
INSERT INTO `autor_v` VALUES (1, 14, 0);
INSERT INTO `autor_v` VALUES (1, 15, 0);
INSERT INTO `autor_v` VALUES (1, 16, 0);
INSERT INTO `autor_v` VALUES (1, 17, 0);
INSERT INTO `autor_v` VALUES (1, 18, 0);
INSERT INTO `autor_v` VALUES (1, 19, 0);
INSERT INTO `autor_v` VALUES (1, 20, 0);
INSERT INTO `autor_v` VALUES (1, 21, 0);
INSERT INTO `autor_v` VALUES (1, 22, 0);
INSERT INTO `autor_v` VALUES (1, 23, 0);

-- --------------------------------------------------------

-- 
-- Štruktúra tabuľky pre tabuľku `buffer`
-- 

CREATE TABLE `buffer` (
  `id` int(11) NOT NULL default '0',
  `id_sekcia` tinyint(4) NOT NULL default '0',
  `bufnazov` varchar(255) NOT NULL default '',
  `buftext` text NOT NULL,
  `expl_obr` varchar(20) NOT NULL default '',
  `strana` tinyint(4) NOT NULL default '0',
  `bufedit` int(11) default NULL,
  `datum` date NOT NULL default '0000-00-00',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Sťahujem dáta pre tabuľku `buffer`
-- 


-- --------------------------------------------------------

-- 
-- Štruktúra tabuľky pre tabuľku `clanok`
-- 

CREATE TABLE `clanok` (
  `id` int(11) NOT NULL auto_increment,
  `clanazov` varchar(255) NOT NULL default '',
  `clatext` text NOT NULL,
  `cladatum` date NOT NULL default '0000-00-00',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- 
-- Sťahujem dáta pre tabuľku `clanok`
-- 

INSERT INTO `clanok` VALUES (1, 'O stránke', '[rmyimg=13.jpg] [stred][velkost=vacsie]Vitajte na stránke[/velkost]\r\n[velkost=obor][farba=oranzova]História Linuxu[/farba][/velkost][/stred]\r\n\r\n[tab][tab]Linux je operaèný systém, ktorý sa v dnešnej dobe hromadne nasadzuje nielen vo firmách a serveroch, ale aj na domácich poèítaèoch. Spoèiatku bol urèený len pre architektúry i386, ale v dnešnej dobe sú známe distribúcie aj pre Motorola 68000 series, Alpha, SUN Sparc, PowerPC, ARM, HP PA-RISC, IA-64, MIPS, MIPS (DEC), IBM s/390 a existujú aj verzie pre vreckové poèítaèe. Viac než 74% superpoèítaèov sveta a prevažná väèšina svetových severov má nainštalovaný Linux. Jeho stabilita, bezpeènos? a otvorenos? ho robí populárnejším a žiadanejším. Vždy to tak nebolo. Linux prešiel dlhú cestu, kým sa mu podarilo vyformova? do dnešnej podoby. Kritika bola spoèiatku naklonená proti tomuto projektu. Jeho filozofia sa mnohým aj v dnešnej dobe zdá by? absorudná. Èas však ukázal, že Linux je plnohodnotný operaèný systém.\r\n\r\n\r\n[cituj]História je neodmyslite¾nou súèas?ou prítomnosti. Ak chceme pochopi? kam smeruje naša budúcnos?, musíme nazrie? do minulosti.[/cituj] [tab][tab]Už sa nepametám kto povedal túto múdru vetu, alebo èi znela doslova takto, ale pri vytváraní tejto stránky som si uvedomil že má pravdu. Pri písaní týchto èlánkov sa stáva èlovek súèas?ou nieèoho vaèšieho ako je on sám. Na tejto stránke sa nenachádzajú bezdušé manuály, ani príruèky a ani diskusie ako rieši? probémy. Nachádzajú sa tu skutoèné príbehy ludí, ktorý v nieèo verili a išli za tým. Táto posledná veta vyznela možno trocha sentimentálne ale viem o èom píšem. Tieto príbehy niesu písané Holywoodskymi scenáristami, ale prežité luïmi, ktorý vzali osud do vlastných rúk.\r\n\r\n\r\n[tab][tab]Táto stránka je moja maturitná práca (SPŠ Jozefa Murgaša Banská Bystrica [b]2007[/b]) a jej cie¾om je priblíži? historický vývoj tohto operaèného systému a projektov ktoré s nim súvisia. Taktiež sa zaoberá historickým vývojom jednotlivých distribúcii. Je interaktívna a viacuživate¾ská,   preto je aj projektom každého kto sa zaregistruje a prispeje èlánkami.', '2007-03-22');
INSERT INTO `clanok` VALUES (2, 'Zrod Linuxu', 'Písal sa rok 1991, bola to doba ve¾kého poèítaèového rozvoja. Nastavalo obdobie zlatého veku pre poèítaèe. Hardware sa èoraz rýchlejšie rozvíjal a bol tlaèený až za limit ktorý sa od neho predpokladal.  Ale stále nieèo chýbalo. Nieèo podstatné bez èoho je poèítaè len drahá kopa súèiastok. Bol to schopný operaèný systém.\r\nV týchto dobách sa stal DOS impériom medzi operaènými systémami. Povodne bol naprogramovaný Seattlelskými hackermi a bol odkúpený Billom Gatesom za 50000 dolárov. Tato atrapa operaèného systému sa dostala do každého kúta sveta dobrou marketingovou stratégiou. Užívatelia poèítaèov nemali ve¾mi na výber. MACS od firmy Apple boli síce lepšie ale omnoho drahšie.\r\nÏalším smerom operaèných systémov bol [vysvet=2]Unix[/vysvet]. Ich obrovská predajná cena však presvedèila bežných užívate¾ov PC, aby od neho ostali èo najïalej.  Zdrojový kód [vysvet=2]Unix[/vysvet] vyvinutý firmou Bell Labs, bol strážený a nepublikovaný. Trh nepodával užívate¾ovi nijaké prijate¾ný kompromis.\r\n\r\nV tom èase sa stal akýmsi riešením tohto problému  [vysvet=1]MINIX[/vysvet]. Bol napísaný Dánskym  profesorom ,žijúcim  v USA,  [vysvet=3]Andrewom S. Tanenbaumom[/vysvet]. Profesorovým cie¾om bolo nauèi? svojich študentov, ako pracuje operaèný systém vo svojom vnútri. [vysvet=1]MINIX[/vysvet] bol navrhnutý, aby bežal na procesoroch Intel 8086. V tých dobách bol trh zaplavený procesormi tohto tipu. \r\n[rmyimg=3.jpg]\r\n[vysvet=1]MINIX[/vysvet] nebol zrovna najlepším operaèným systémom, ale mal výhodu v tom, že jeho zdrojový kód bol dostupný.\r\nKtoko¾vek si kúpil knihu :\r\n[velkost=velke]OPERATING SYSTEMS: DESIGN AND IMPLEMENTATION BY TANENBAUM[/velkost]\r\nmal v rukách 12000 riadkov kódu, napísaného v jazykoch C a Assembler. Prvý krát v histórii si mohol programátor preèíta? zdrojový kód operaèného systému. V tom èase to bolo nieèo nepredstavite¾né, lebo predajcovia operaèných systémov si svoje kódy strážili ako oko v hlave. \r\n\r\n[vysvet=3]Tanenbaum[/vysvet] spôsobil rozjasnenie v mysliach programátorov. Zaèali sa diskusie o umení vytvárania a pracovania operaèných systémov. Študenti poèítaèových vied z celého sveta študovali a snažili sa pochopi? kódy a systém bežiaci na ich poèítaèi. Jedným z nich bol [vysvet=4]Linus Torvalds[/vysvet].\r\n\r\n\r\n\r\nV roku 1991 bol [vysvet=4]Linus Benedict Torvalds[/vysvet] študentom druhého roèníka na Helsinskej univerzite Tento 21 roèný Fínsky študent miloval využívanie možností poèítaèov. Cítil však neprítomnos? operaèného systému ktorý by uspokojil profesionálov. [vysvet=1]MINIX[/vysvet] bol celkom dobrý, ale jednoduchý. Bol skôr urèený na vyuèovanie než na skutoèné používanie. \r\n\r\n[rmyimg=4.jpg]V tom istom èase sa programátori z celého sveta inšpirovali a nadchýnali myšlienkami [vysvet=5]GNU[/vysvet] projektu od [vysvet=6]Richarda Stallmana[/vysvet] (Jeho fotografia je na pravo).\r\nMyšlienka softwaru ktorý by bol kvalitný a pritom zadarmo, spôsobila, že vtedajšia poèítaèová  spoloènos? uznávala [vysvet=6]Stallmana[/vysvet] ako hrdinu. [vysvet=6]Stallman[/vysvet] zaèal svoju kariéru v slávnej spoloènosti [vysvet=7]Artificial Intelligence Laboratory (AI labs)[/vysvet]. V polovici sedemdesiatych rokov vytvoril editor Emacs. \r\nZaèiatkom osemdesiatych rokov prilákali komerène spoloènosti k sebe množstvo geniálnych programátorov z [vysvet=7]AI labs[/vysvet]. Svoje softwarové tajomstvá si nechávali iba pre seba. [vysvet=6]Stallman[/vysvet] mal však inú víziu. Software by na rozdiel od iných produktov nemal by? chránený proti kopírovaniu a modifikovaniu za úèelom vytvárania lepších a efektívnejších poèítaèových programov. V roku 1983 sa uskutoènil jeho slávny manifest ktorý odštartoval zaèiatky [vysvet=5]GNU[/vysvet] projektu. Zaèal robi? ?ahy na vytváranie softwaru ktorý niesol jeho filozofiu. Aby však uskutoènil tento sen, vedúci k vzniku operaèného systému , musel vytvori? nástroje. V roku 1984 napísal GNU C Compiler (GCC). Bol to neocenite¾ný èin pre individuálnych programátorov. GCC prekonal aj komerèné produkty a považoval sa za najlepší kompilátor aký kedy bol stvorený. \r\n\r\nUž v roku 1991 malo [vysvet=5]GNU[/vysvet] stvorené množstvo nástrojov, ale stále na obzore žiaden poriadny operaèný systém. Zahájili sa síce prace na [vysvet=5]GNU[/vysvet] jadre HURD, ale to malo prís? na svet až o pár rokov. [vysvet=4]Linus[/vysvet] bol však netrpezlivý.\r\n\r\n[farba=cervena]25 augusta 1991[/farba] bola zaslaná správa pre MINIX news grup, ktorá znamenala žaèiatok novej éry.\r\n[cituj]Od: torvalds@klaava.Helsinki.FI (Linus Benedict Torvalds) \r\nNewsgroups: comp.os.minix \r\nPredmet: Èo by ste najradšej videli na MINIXE?  \r\nMessage-ID: <1991Aug25.205708.9541@klaava.Helsinki.FI> \r\nDate: 25 Aug 91 20:57:08 GMT \r\nOrganization: University of Helsinki  \r\n\r\n\r\nZdravím všetkých používate¾ov MINIXu  - \r\nPracujem na (free) operaènom systéme (je to iba hoby, nebude taký profesionálny ako GNU) pre 386 (486) AT poèitaèe. Vyvíjam ho od apríla a zaèína by? hotový. Rad by som poèul názory èo sa ¾uïom páèi/nepáèi na MINIXe, pretože môj operaèný systém sa mu podoba tak trochu (to isté fyzické rozdelenie súborového systému (z praktických dôvodov) a iné veci). Už som nahodil bash (1.08) a gcc(1.40). Zdá sa, že všetko funguje ako má. Z tohto vyplýva, že prídem s nieèim použite¾ným za pár mesiacov, preto chcem vediet názory ¾udí èo by najradšej chceli. Akéko¾vek návrhy sú vítané, ale nemôžem s¾úbi?, že ich zrealizujem :-)\r\nLinus (torvalds@kruuna.helsinki.fi)\r\nP.S. Ano, je bez akéhoko¾vek minixového kodu a má multi-threaded fs, ale pravdepodobne nikdy nebude podporova? iné ako AT-harddisky, pretože iba takéto mám :-(\r\n[/cituj]\r\nOriginál správy (v angliètine) nájdete[vysvet=8] tu[/vysvet].\r\n\r\nZo správy vidno, že [vysvet=4]Linus[/vysvet] nepredpokladal, že jeho stvorenie bude dostatoène dobré, aby zmenilo poèítaèový svet. Linux verzia 0,01 bola uvedená v polovici Septembra 1991 a bola zverejnená na internete. Kódy boli s?ahované, testované, vylepšované a neskôr zaslané Linusovy naspä?. Verzia 0,02 prišla na svet [farba=cervena]5 októbra[/farba] spoloène aj s vyhlásením Linusa:\r\n[cituj]Od: torvalds@klaava.Helsinki.FI (Linus Benedict Torvalds) \r\nNewsgroups: comp.os.minix \r\nPredmet: Free operaèný systém podobný MINIXU \r\nMessage-ID: <1991Oct5.054106.4647@klaava.Helsinki.FI> \r\nDate: 5 Oct 91 05:41:06 GMT \r\nOrganization: University of Helsinki \r\n\r\nChýbajú Vám èasi MINIX-1.1, kedy  ¾udia boli pánmi a písali si vlastné ovládaèe?\r\nNemáte niè na práci a najradšej by ste sa pustili na operaèný systém ktorý môžete modifikova? pod¾a vlastných potrieb?\r\nFrustruje Vás, že všetko beží pod MINIXom? \r\nChýbajú Vám noci strávene za poèítaèom, len aby ste rozbehali prefíkaný porgram?\r\nPotom je táto správa urèená Vám.\r\n\r\nAko som pred mesiacom spomínal, pracujem na free verzii operaèného systému podobnému MINIXu pre poèítaèe AT-386. Koneène je v štádiu použite¾nosti. Je to iba verzia 0.02 (+1 malý patch). Podarilo sa mi už rozbeha? bash/gcc/gnu-make/gnu-sed/compress a iné. Zdrojový kód je na nic.funet.fi (128.214.6.100) v prieèinku /pub/OS/Linux. Adresár obsahuje aj nieko¾ko README súborov. A zopár binárnych vecièiek ktoré idú pod linuxom (bash, updaty a gcc. Èo viac si èlovek môže pria? :- ) Celé jadro je poskytnuté ako ešte žiaden minix kód nebol. Knižnice sú iba z èasti free, takže nemôžu by? distribuované. Zdrojový kód a binárne súbory (bash and gcc)  možno nájs? na rovnakom mieste v /pub/gnu\r\n[/cituj]\r\nOriginál správy (v angliètine) nájdete [vysvet=9] tu [/vysvet].\r\n\r\nLinux verzia 0.03 prišla o pár týždòov. V decembri bola na svete už verzia 0.10. Linux mal stále ešte len formu akejsi kostry operaèného systému. Nemal ešte žiadne prihlasovanie. (Bootoval sa priamo do BASHu). Verzia 0.11 bola omnoho lepšia, podporoval viaceré klávesnice, disketové mechaniky, disky. Od verzie 0.12 sa zaèalo èíslovanie od 0.95 , 0.96 atd. \r\n\r\nNeskôr èelil [vysvet=4]Linus[/vysvet] [vysvet=3]Andrew Tanenbaumanovi[/vysvet], v¾kému profesorovi ktorý napísal [vysvet=1]MINIX[/vysvet]. V sprave ktorú [vysvet=3]Tanenbaum[/vysvet] napísal [vysvet=4]Linusovi[/vysvet] stálo:  \r\n[cituj]Stále zastávam názor, že v roku 1991 vytvára? monolitické jadro je podstatná chyba. Buïte rád, že nieste môj študent. Dostali by ste dos? zlú známku za takýto návrh jadra :- )[/cituj]\r\nOriginál správy (v angliètine) nájdete [vysvet=10] tu [/vysvet].\r\n\r\n[vysvet=4]Linus[/vysvet] neskôr priznal, že to bol preòho najhorší bod vo vývoji  Linuxu. [vysvet=3]Tanenbaum[/vysvet] bol síce pôsobivý profesor a všetko èo povedal zavážilo. Nemal však pravdu o Linuxe. [vysvet=4]Linus[/vysvet] bol však chvalabohu tvrdohlavý a nepriznal prehru.\r\n\r\n[vysvet=4]Linus[/vysvet] podporovaný ve¾kou Linuxovou komunitou odpisal [vysvet=3]Tanenbaumovi[/vysvet]:\r\n\r\n[cituj]Vašou prácou je by? profesor a výskumník. To je dobré ospravedlnenie za škody na mozgoch ktoré napáchal MINIX\r\n[/cituj]\r\nOriginál správy (v angliètine) nájdete [vysvet=11] tu [/vysvet].\r\n\r\nPráce pokraèovali. Èoskoro mal tábor linuxu stovky, neskôr tisícky, neskôr stotisíce priaznivcov. Linux už nebol len „hraèkou hackera“. Podporovaný hojným poètom [vysvet=5]GNU[/vysvet] programov bol pripravený ukáza? sa v plnej kráse. Aby sa zaistilo, že zdrojový kód ostane vo¾ne širite¾ný bol licencovaný pod [vysvet=5]GNU[/vysvet] General Public License.\r\n\r\nNastúpil na scénu komerèné spoloènosti. Linux bol je a bude zadarmo. Spoloènosti však zozbierali a skompilovali software a potom ho ako celok predávali. Spoloènosti ako Red Hat a Candera si získali množstvo priazne. Kým tu sa jednalo o komerciu, horlivý programátori vytvorili svoju vlastnú distribúciu Debian. S novými grafickými prostrediami (Grapical User Interface), ako napríklad KDE, Gnome, X-window sa stával Linux èoraz populárnejší. \r\n\r\n[lmyimg=5.jpg]Medzitým sa diali neuverite¾né zázraky s Linuxom. Povodne bol stvorený pre platformu PC. Teraz sa však zaèal rozširova? na iné platformy. Linux bol prerobený aby bežal aj na vreckových poèítaèoch PalmPilot. V apríly 1996 použili výskumníci  z Los Alamoskeho Národného Laboratória  (Los Alamos National Laboratory)  Linux, na 68 poèítaèoch. Pospajali ich tak, že pracovali ako jeden procesor na simuláciu tlakových vån. Na rozdiel od ostatných “Superpoèítaèov”, ktoré stáli celý majetok, stál tento podomácky vytvorený superpoèítaè iba 152 000 dolárov. Superpoèítaè pracoval na rýchlosti 19 miliárd kalkulácii za sekundu a to ho robilo 315tym najvýkonnejším poèítaèom sveta. Zaujímavos?ou je aj fakt, že ani po troch mesiacoch neustálej práce ho nebolo treba neštartova?. \r\n\r\n[vysvet=4]Linus[/vysvet] (fotografia v¾avo) naïalej ostal jednoduchým èlovekom. Nie je miliardár. Po dokonèení štúdia sa pres?ahoval do USA a prijal miesto v spoloènosti TRANSMETA. Neskôr sa oženil s láskou jeho života Tove. Má dcéru Patriciu Mirandu Torvaldsovú. Navždy sa však zapíše ako svetovo najpopulárnejší a najuznávanejší programátor.', '2007-03-20');
INSERT INTO `clanok` VALUES (3, 'Zrod GNU', '[lmyimg=6.jpg]V roku 1971 zaèal [vysvet=6]Richard Stallman[/vysvet] pracova? v MIT  [vysvet=7]Artificial Intelligence Laboratory[/vysvet]. [vysvet=7]AI lab[/vysvet] používalo operaèný systém ITS navrhnutý [vysvet=14]hackermi[/vysvet] labolatória pre poèítaè Digital PDP-10. [vysvet=6]Richard[/vysvet] bol v týme, ktorého úlohou bolo vylepšova? tento systém. V tychto dobách pojem [b]slobodný software[/b] ešte nexistoval ale ITS ním bol. Ktoko¾vek chcel vidie? zdrojové kody, alebo ho používa? mal tú možnos?. \r\nZaèiatkom osemdesiatých rokov, z dôvodu zastaralej stavby, prestala firma Digital vyrába? PDP-10. To sposobilo, že všetky programio pre ITS boli zastaralé. Komunita [vysvet=14]Hackerov[/vysvet] z [vysvet=7]AI Labs[/vysvet] sa rozpadla. Väèšinu si najala firma Symbolics. V roku [farba=cervena]1982[/farba] nakúpilo [vysvet=7]laboratórium[/vysvet] nové PDP-10 a ich administrátori sa rozhodli použi? na nich neslobodný systém od firmi Digital namiesto ITS. \r\nNový operaèný system mal kopu obmezeni a kopu uživatela obmezujúcich záväzkov. Pod¾a [vysvet=6]Richarda[/vysvet]  myšlienka systému v ktorom nesmiete zdiala?, alebo meni? software je zlá a netická. Ak chcel užívate¾ nieèo v softwary zmeni? musel o to poprosi?. Ak chcel zdiela? software s kolegom, stal sa pirátom. Prakticky bol užívate¾ otrokom svojho systému.\r\n\r\n[vysvet=6]Richarda[/vysvet] mal dve možnosti. Podpísa? [farba=maroon]non-disclosure agreement[/farba] (súhlasi? s obmezujúcimi podmienkami) a k¾udne zarába? peniaze, alebo odís? z práce, ktorú miloval.\r\n\r\n[vysvet=6]Richard[/vysvet] nezapredal svoju dušu diablovi a h¾adal spôsob, akým by sa vratil k starým dobrým a hlavne slobodným èasom. V januáry 1984 odišiel z MIT a rozhodol sa vytvorit nový operaèný systém podobný Unixu (UNIX like operation system). Vznikol projekt [vysvet=5]GNU[/vysvet]. Keby [vysvet=6]Richard[/vysvet] ostal v MIT pravdepodobne by si jeho projekt privlastnili a uvalily by naò svoje licencie. \r\n\r\nUvedomoval si, že to nebude precházka ružovou záhradou. Nový operaèný systém musí obsahova? procesory, assemblery, kompilátory, prekladaèe, editory.Prvým krokom bol prekladaè. Pôvodne chcel [vysvet=6]Richard[/vysvet] použi? slobodný prekladaè [b]VUCK[/b]. Napísal autorovi, ale dostal odpoveï nie. Ïa¾ším pokusom bol multiplatformoví prekladaè [b]Pastel[/b] od Lawrence Livermore Lab. Snažil sa ho naportova? na poèítaè Motorola 68000, ale pre nedostatok vo¾ného priestoru sa aj tohto pokusu musel vzda?. Nakoniec pochopil, že jediný spôsob ako získa prekladaè je ked ho sám napíše. V ten istý rok prišiel na svet prekladaè GCC.\r\nV roku 1985 napísal [vysvet=5]GNU[/vysvet] editor Emacs a zaèal ho predáva? na páskach. \r\n\r\n[stred][farba=oranzova]Filozofia slobodného softwaru sa nestavia proti komercii, pokial obchod rešpektuje slobody užívate¾a.[/farba][/stred]\r\n\r\nNastali však obavy, že by zaèali proprietárne spoloènosti vklada? [vysvet=15]slobodný software[/vysvet] do svojho neslobodného softwaru.  Z takejto kombynácie by vznikol ïa¾ší neslobodný software. Táto skutoènos? priviedla [vysvet=6]Richarda[/vysvet] k myšlienke [b]copyleftu[/b]. Copyleft funguje podobne ako copyright ale obrátene. Namiesto aby spútal software, zaistí jeho slobodu.\r\nVznikla licencia GPL (General Public Licence) ktorá zaistovala, že autor musí k programu spristupni? aj zdrojové kódy. Ak bol software upravený, musí by? naïalej šírený pod GPL\r\n\r\nV roku 1985 nznikla [b]nadácia pre slobodný software[/b].[rmyimg=8.jpg] Zais?ovala prísun financii jednak od sponzorov i z predaja pások s Emacsom. Neskôr sa predávali aj príruèku, CD-ROMy so zdrojovýmy kódmi (všetko vrámci slobody). Èoraz viac a viac ¾udí zaèalo pomáha? [vysvet=5]GNU[/vysvet] projektu. ', '2007-03-20');
INSERT INTO `clanok` VALUES (4, 'Slackware', '[velkost=velke][b]Zaèiatok Slackwaru[/b][/velkost]\r\n\r\nPo istej dobe, ako [vysvet=4]Linus Torvalds[/vysvet] zverejnil svoje zdrojové kód na internete, zaèali sa objavova? prvé distribúcie. Medzi najpopulárnejsie patrili [farba=fialova]H.J. Lu`s "Boot-root"[/farba], [farba=fialova]MCC Interim Linux[/farba], [farba=fialova]TAMU[/farba] a [farba=fialova]SLS[/farba]. Mali zopár nástrojov, ale ich popularita narastala. Napriek vtedajšej oblúbenosti sú už dnes neaktívne. Hlavným dôvodom preèo spomínam tieto prvotné distribúcie je, že Slackware mnohí považujú za úplne prvú distribúciu. V skutoènosti sa Slackware objavil až [farba=cervena]16 júla 1993[/farba], teda rok po distribúcii [vysvet=17]SLS[/vysvet].  \r\nTvorcom Slackwaru je Patrick Volkerding (obrázok vpravo). [rmyimg=10.jpg]Spoèiatku Patrick upravoval distribúciu [vysvet=17]SLS[/vysvet] pre svoj projekt do školy. V skutoènosti nechcel  robi? vlastnú distribúciu, ale jeho profesor chcel vidie? ako sa inštaluje Linux. Taktiež ho chcel na domáce použitie a pre svojich študentov. Tak Patrick doniesol do poèítaèového laboratória univerzity SLS. Patrick už mal svoje skúsenosti s chybami tejto distribúcie a keïže tu ich musel opravova? na každom poèítaèi zvláš? zabralo to more èasu. Vtedy prišiel jeho profesor s nápadom opravenie týchto chýb priamo na inštalaènom disku. Toto bol zaèiatok Slackwaru. Patrick opravil chyby, pridal zopár balíèkov, neskôr pridával vlastné skripty, vlastné konfiguraèné súbory. Rozdiel medzi originálnym [vysvet=17]SLS[/vysvet] a Patrickovým [vysvet=17]SLS[/vysvet] už nebol len v nieko¾kých “kozmetických“ úpravách. Postupom èasu viac a viac Patrickových priate¾ov chcelo, aby svoju distribúciu zverejnil na FTP. On sa však zdráhal, pretože vedel, že sa má èoskoro ukáza? na svete nová verzia [vysvet=17]SLS[/vysvet] (s novým jadrom Linuxu). Vyèkal pár týždòov a videl, že ¾udia zaèínajú by? nervózny. Po dohode s administrátorom MSU (Moorhead State University) otvoril anonymný FTP server. Tí èo si stiahli Slackware 1.0, písali o tejto distribúcii pekné veci. Toto Patrika povzbudilo k ïalším verziám. \r\n\r\nMeno distribúcie je odvodené od slova slack (nepoznaný). Tento názov Patrickovy doporuèil jeho priate¾ J.R.Dobbs. Patrick nechcel, aby niekto bral jeho distribúciu vážne, tak súhlasil s týmto názvom. Dnes je však Slackware ve¾mi známy a ve¾mi ob¾úbený. Krátku dobu mu s prácou na Slackware pomáhal Chris Lumens a iný, ale posledné roky pracuje na distribúcii sám. Kríza Slackwaru nastala v roku 2004, keï bol Volkerding dlhodobo chorý. Patrick bol prevezený a lieèený na klinike Mayo. Hrozil koniec tejto vinikajúcej distribúcie a fanúšikovia Slackwaru boli v obavách. 18 decembra ich upokojila správa, že sa Patrick pomaly zotavuje a vracia k svojej ob¾úbenej práci.\r\n\r\n[velkost=velke][b]Slackware ako distribúcia[/b][/velkost]\r\n[rmyimg=11.jpg]Slackware je predovšetkým urèený pre tých, ktorý vyžadujú stabilný, bezpeèný systém a radi ho nastavujú. Zárukou stability je jeho dlhoroèná tradícia. V priebehu vývoja sa nesnažil napodobòova? operaèný systém Windows, snažil sa by? èo najviac [vysvet=18]Unix-like[/vysvet]. Typické pre Slackware je tradièná a osvedèená metóda konfigurácie editovaním súborov. Inštalácia distribúcie je v grafickom menu v textovej konzole. Používa vlastný balíèkový systém postavený na tgz (tar balík skomprimovaný gzipom).\r\nPôvodne bol vyvíjaný na architektúru x86 PC, vyskytli sa však aj oficiálne verzie pre architektúry DEC Alpha a SPARC. Existujú aj neoficiálne Slackware distribúcie pre archytektúry PowerPC a x86-64.\r\n\r\nJe všeobecne známe, že užívatelia Slackwaru sú najspokojnejší Linuxáci, preto si bude naïalej drža? titul [b]Najstaršej aktívnej distribúcie[/b].\r\nŽelám Patrickovy ve¾a zdravia, aby nadalej existovala táto vynikajúca distribúcia.\r\n\r\nZoznam distribúcii založených na slackware najdete [url=http://en.wikipedia.org/wiki/Slackware#Distributions_based_on_Slackware]tu[/url]\r\n\r\n[velkost=velke][b]Zdroje informácii a odkazy týkajúce sa tematiky[/b][/velkost]\r\n[url=http://slackbook.org/]Slackbook.org [EN][/url], [url=http://www.slackware.com/]Slackware.com [EN][/url], [url=http://www.linuxjournal.com/article/2750]LinuxJournal.com [EN][/url], [url=http://www.czslug.cz/]czslug.cz [CZ][/url], [url=http://en.wikipedia.org/wiki/Slackware/]Wikipedia.org [EN][/url], [url=http://cs.wikipedia.org/wiki/Slackware/]Wikipedia.org [CZ][/url], [url=http://en.wikipedia.org/wiki/SLS_Linux/]Wikipedia.org (o SLS)[EN][/url], [url=http://sk.wikipedia.org/wiki/Slackware/]Wikipedia.org [SK][/url], [url=http://distrowatch.com/table.php?distribution=slackware]DistroWatch.com [SK][/url], [url=http://distrowatch.com/table.php?distribution=slackware]DistroWatch.com [SK][/url], [url=http://linuxos.sk/index.php?show=clanok&id=198]LinuxOS.sk [SK][/url]', '2007-03-20');
INSERT INTO `clanok` VALUES (5, 'Debian', '[rmyimg=12.jpg]Presne mesiac po tom ako sa na svete objavila distribúcia Slackware, obiavila sa sprava [b]Iana Murdocka[/b] ([farba=cervena]16.august 1993[/farba]) oznamujúca svetu vyvíjanie distribúcie [b]Debian[/b].\r\n \r\n[velkost=velke][b]Poèiatok[/b][/velkost]\r\n\r\nIan Murdock (obrázok vpravo)  bol toho èasu študentom poèitaèových vied na univerzite Purdue  (Purdue University, West Lafayette štát Indiana). Ako mnohý iný aj on používal spoèiatku distribúciu  [vysvet=17]SLS[/vysvet] a nebol sòou úplne spokojný. Narazil na kopu chýb, ktoré chcel spoèiatku opravova? vo forme patchov. Neskôr si uvedomil, že[vysvet=17]SLS[/vysvet] je až moc deravý na jeho záplaty. \r\nNa druhej strane sa Ianovi nepáèila uzavretos? vtedajších distribúcii. Je pravdou, že software bol otvorený, ale distribúcie sa vyvýjali v istej izolacii pred svetom. V praxi to vypadalo tak, že na vtedajších distribúciách pracovali len iste tými a nikto iný. Vezmime si napríklad Slackware od Patricka Volkerdinga. Je pravdou, že svoju prácu robí Patrick výborne, ale úplne individuálne. Ian mal iný názor. Hlásal rovnakú otvorenos? distribúcii, akú mal vývoj Linuxu. Na svete chcel vidie? distribúciu vyvíjanú každým a pre každého. Cie¾avedomý 20 roèný študent sa zaèal pohráva? s myšlienkou vlastnej distribúcie. Distribúcie, ktorá by bolo pod¾a jeho predstav, pod¾a toho èo sa jemu páèi. Pre Iana to bola výzva.  \r\n\r\n[velkost=velke][b]Prvé 0.x verzie[/b][/velkost]\r\n\r\nPo niekých týždòoch práce za monitorom bola distribúcia takmer hotová. Ian zvolil pre svoju distribúciu meno [farba=modra]Debian[/farba]. Vskutku toto slovo simbolizuje viac než len software. Simbolizuje lasku medzi Ianom a jeho priate¾kou (neskôr aj manželkou) Debrou  [farba=modra]Deb[/farba]+[farba=modra]Ian[/farba]. [b]Debian 0.91[/b] bol oficialne zverejnený v [farba=cervena]janury 1994[/farba]. Na projekte vtedy pracoval asi tucet ¾udí, no aj tak Ian spravil väèšinu. Pridávalo sa viac a viac programátorov.V [farba=cervena]novembri 1994[/farba] dostal projekt debian sponzorskú podporu od [vysvet=19]The Free Software Foundation[/vysvet]. [farba=cervena]1 decembra 1994[/farba] sa rozhodol napísa? [farba=modra]Debian manifesto[/farba]. Zhrnul tu všetky mišlienky a ciele Debianu. [b]Debian 0.93 Release 5 [/b] sa ukázal v [farba=cervena]marci 1995[/farba] a bola to na tú dobu výborne spravená distribúcia. Používal vlastný balíèkový systém [b]dpkg[/b]. V novembri toho istého roka prišla na svet [b]Debian 0.93 Release 6[/b]. Na projekte vtedy pracovalo okolo 60 programátorov a vtedy Ian pochopil, že Debian sa len tak ¾ahko zo sveta nevytratí. Jeho sen sa naplnil. V roku 1995 Hartmut Koptein naportoval Debian do poèítaèa Atari Medusa 68040 (architektúra Motorola m68k). Neskor Vincent Renardias a Martin Schulze naportovali Debian na poèítaèe archytektúry PowerPC. \r\n\r\n[velkost=velke][b]Zákulisie 1.x verzie[/b][/velkost]\r\n\r\nPred nastupom [b]Debian 1.1[/b] odstúpil Ian Murdock z pozície vedúceho projektu. Novým šéfom sa stal [b]Bruce Perens[/b]. Bruce sa prvý krát stretol s Debianom, keï sa pokúšal spravi? distribúciu pre amatérske operácie. Mala nies? názov [i]Linux for Hams[/i]. Neskor si Bruce uvedomil, že viac bude užitoènejší pre Debian. Vzdal sa svojej distribúcie a zaèal tvori? pre Debian. Ian pred odchodom vyhlásil, že Bruce je prirená vo¾ba, ktorá zaistí ten správny a rýchly rozvoj tejto distribúcie. Za Brucovho pôsobenia si získal Debian reputáciu serióznej distribúcie. Jeho stratégia podpory užívate¾ov free priruèkami a technickou podporou spravila Debian to èím je dnes. \r\nV tomto èase vyšli tieto distribúcie:\r\n\r\nDebian 1.1 Buzz  -  Jún 1996 (474 soft. balíèkov, kernel 2.0)\r\nDebian 1.2 Rex   -  December 1996 (848 soft. balíèkov, 120 vyvojárov na projekte)\r\nDebian 1.2 Bo    -  Júl 1997 (974 soft. balíèkov, 200 vyvojárov na projekte)\r\n\r\nV [farba=cervena]January 1998[/farba] bol Bruce Perens vymenený Ianom Jacksonom, pretože prípravy novej verzie Debianu 2.0 viedol až moc posvojom.\r\n\r\n[velkost=velke][b]Svet, predstavuje sa ti Debian 2.x[/b][/velkost]\r\n\r\nIan Jackson sa stal vodcom projektu Debian zaèiatkom roka 1998 a jeho Viceprezidentom. Po odstúpení pokladníka (Tim Sailer), prezidenta Bruce Perens) a tajomníka (Ian Murdock) sa stal prezidentom celého projektu. Na post viceprezidenta bol dosadený Martin Schulze, na post tajomníka Dale Scheetz a na post pokladníka Nils Lohner.\r\n\r\nDebian 2.0 (Hamm) bol vydaný v [farba=cervena]júly 1998[/farba] pre archytektúry Intel i386 a Motorola 68000. Toto vydanie prešlo na novú verziu knižníc jazyka C (glibc2, alebo libc6). Táto distribucia ponúkala viac ako 1500 softwarových balíèkov a pracovalo na nej viac ako 400 vývojárov.\r\n\r\nDebian 2.1 (Slink) sa ukázal svetu [farba=cervena]9. marca 1999[/farba]. Bol sprevádzaný nieko¾kými opravami na poslednú chví¾u. Oficialne podporoval aj archytektúry Alpha a Sparc. Distribúcia mala výborne prepracovaný X-Windows a nové rozhranie balièkového manažéra. Vzh¾adom na to, že obsahovala 2250 balíèkov, bol Debian 2.1 spracovaný na 2CD.\r\n\r\n[farba=cervena]21. apríla 1999[/farba] uzavrela spoloènos? [b]Corel Corporation[/b] a [b]K Desktop Project[/b] spojenectvo na vytvorenie distribúcie založenej na Debiane s prostredím od [vysvet=22]KDE[/vysvet] group. Behom tohoroèného leta, sa obiavila nová na Debiane založená distribúcia [b]Storm Linux[/b]. Projekt Debian si zvolil nové logo na oficiálne Debian materialy (CD-ROMy, oficialna stránka) ako i neoficiálne logo na materialy založené na Debiane.\r\n\r\nTohoèasu sa skúšalo naportova? na debian jadro [vysvet=20]HURD[/vysvet].\r\n\r\nDebian 2.2 (Potato) vyšiel [farba=cervena]15. augusta 2000[/farba] pre archytektúry Intel i386, Motorola 68000, alpha, SUN Sparc, PowerPC, ARM . Vydanie obsahovalo viac ako 3900 binárnych a viac ako 2600 zdrojových balíèkou na ktorých pracovalo viac ako 450 vývojárov. Zaujmavým faktom na Debiane 2.2 bolo to, že poukazoval, ako free operaèný system može by? omnoho lepší ako komerèný. Toto štúdium bolo zhrnuté v dokumente zvanom [i]Counting potatoes[/i].\r\n\r\n[velkost=velke][b]Debian 3.x[/b][/velkost]\r\n\r\nTak ako predošlé generácie aj Debian 3.x predcházaly rosiahle zmeny. Tentokrát sa však nediali len vo vedení. Corel predal svoju Linux diviziu zaèiatkom roka 2001, Stormix vyhlásil bankrot 17 januára 2001 a Progeny zavrhol vytváranie svojej distribúcie v oktobry 2001. Boli zvolený nový vedúci projektu [b]Ben Collins[/b] (v roku  2001) and [b]Bdale Garbee[/b]\r\n\r\nVydanie novej verzie zmrzlo [farba=cervena]1. júla 2001[/farba], kôli rosiahlým úpravám vnútra distribúcie a inym problémom. Napriek tomu sa dial pokrok v iných oblastiach projektu. Webová stránka Debianu bola preložená do 20 roznych jazykov a inštalácia do 23 jazykov. Zaèali sa dva nové projekty [b]Debian Junior[/b] (pre deti )a [b]Debian Med [/b] (pre medicínske prostredie). Vývoj softwareových balíèkov taktiež neustál. Boli zvolané mítingy vývojárov pod názvom [b]Debconf[/b]. Prvý sa udial v Bordeaux (Francúzko) a druhý v Toronte (Kanada).\r\n\r\nDebian 3.0 (Woody) bol vydaný [farba=cervena]19. júla 2002[/farba] pre archytektúry Intel i386, Motorola 68000 series, alpha, SUN Sparc, PowerPC, ARM, HP PA-RISC, IA-64, MIPS, MIPS (DEC) a IBM s/390. Vydanie obsahovalo okolo 8500 balíèkov na ktorých pracovalo viac ako 1000 vývojárov. Vydanie bolo dostupné na DVD aj na CD-ROMoch.\r\n\r\nPred vydaním ïa¾šej verzie sa udial ïa¾ší (štvrtý) míting [b]Debconf[/b] 18 - 20 júla 2003. Zúèastnilo sa asi 120 vývojárov. Piatý miting sa udial 26 mája - 2 júna 2004 v Porto Alegre (Brazilia). Tentokrát prišlo 160 úèastníkov z 26 krajín.\r\n\r\nDebian 3.1 (sarge) sa ukázal svetu [farba=cervena]6. júna 2005[/farba]  a podporoval rovnaké archytektúry ako Debian 3.0 (Woody). Taktiež vyšiel aj neoficiálny port na AMD64. Táto verzia obsahovala 15000 balíèkov na ktorej pracovalo viac ako 1500 vývojárov. Najviac zmien na tomto vydaní sa týkalo softwaru. Vývojáry museli updatova? viac ako 73% softwaru z predcházajúcej verzie. Obsahoval Linux kernel 2.4 a 2.6, XFree86 4.3, GNOME 2.8 a KDE 3.3. Taktiež sa zmeny týkali aj inštalácie. Obrovským pokrokom bolo aj to, že obsahoval aj kopu softwaru pre ¾udí s postihnutiami. \r\n\r\nŠiesty Debconf sa udial v Espoo (Fínsko 10 - 17 júl 2005 zúèastnilo sa viac ako 3000 úèastníkov) a siedmy Debconf sa udial v Oaxtepec (Mexico 14 - 22 máj 2006)\r\n\r\n[velkost=velke][b]Vodcovia projektu Debian[/b][/velkost]\r\n \r\nIan Murdock založil Debian v augustr 1993 a viedol ho do marca 1996. \r\nBruce Perens viedol Debian od apríla 1996 do decembera 1997. \r\nIan Jackson viedol Debian od januára 1998 do decembera 1998. \r\nWichert Akkerman viedol Debian od januára 1999 do marca 2001. \r\nBen Collins viedol Debian od apríla 2001 do apríla 2002. \r\nBdale Garbee viedol Debian od apríla 2002 do apríla 2003. \r\nMartin Michlmayr bol zvolený v marci 2003 a držal si pozíciu do marca 2005. \r\nBranden Robinson bol zvolený v apríli 2005 a držal si pozíciu do apríla 2006. \r\nAnthony Towns bol zvolený v apríli 2006 a je vedúci doteraz. \r\n\r\n\r\n[velkost=velke][b]Debian ako distribúcia[/b][/velkost]\r\n\r\nDebian bol od svojho poèiatku nekomerèna a nezisková distribucia. Je založený na dobrovo¾níkoch organizovaných pod¾a troch [vysvet=23]zak¾adate¾ských dokumentov[/vysvet].\r\nV priebehu vývoja sa snažil by? pre sovojích uživate¾ov oporou, èi už množstvom free príruèiek i podpory užíva?ela. Snaží sa by? èo najdokonalejšou distribúciou a vyvíja? sa i nadalej v duchu ideí GNU a Linuxu. Podporuje množstvo poèitaèových archytektúr. Debian sa vyznaèuje osobitým, ale široko podporovaným balièkovým systémom. najnovšie sa vyvíja nová (nestabilná) verzia Debianu s prezývkov [i]Sid[/i]. Meno dostala po zlom (nestabilnom) chlapcovy z rosprávky Toy Story. Ak si zvolíte Debian, ako distribuciu, zveríte sa do rúk viac ako 3000 odborníkom, ktorý Vás budú vždy podporova?.\r\n \r\n[velkost=velke][b]Zdroje informácii a odkazy týkajúce sa tematiky[/b][/velkost]\r\n[url=http://en.wikipedia.org/wiki/Debian]Wikipedia.org [EN}[/url], [url=http://www.linuxjournal.com/article/2841]LinuxJournal.com [EN}[/url], [url=http://ianmurdock.com/?page_id=215]IanMurdock.com [EN}[/url], [url=http://www.linuxplanet.com/linuxplanet/editorials/4959/1/\r\n]LinuxPlanet.com [EN}[/url], [url=http://groups.google.com/group/comp.os.linux.development/msg/a32d4e2ef3bcdcc6]List Iana Murdoka[EN}[/url], [url=http://www.debian.cz/info/about.php]Debian manifesto[EN}[/url],\r\n[url=http://www.debian.org/doc/manuals/project-history/ap-manifesto.en.html]Debian manifesto- Hlavny zdroj informacií[EN}[/url], [url=http://www.linuxplanet.com/linuxplanet/editorials/4959/1/]LinuxPlanet.com[EN}[/url], [url=http://tllts.org/mirror.php?fname=tllts_83-05-11-05.mp3]interviu.mp3[EN}[/url]', '2007-03-20');

-- --------------------------------------------------------

-- 
-- Štruktúra tabuľky pre tabuľku `expl`
-- 

CREATE TABLE `expl` (
  `id` int(11) NOT NULL auto_increment,
  `vyraz` varchar(255) NOT NULL default '',
  `vysvetlenie` text NOT NULL,
  `datum` date NOT NULL default '0000-00-00',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

-- 
-- Sťahujem dáta pre tabuľku `expl`
-- 

INSERT INTO `expl` VALUES (1, 'MINIX', 'Operaèný systém na báze operaèného systému UNIX napísaný [b]Profesorom Andy Tanenbaumom[/b].[n] MINIX je prvý operaèný systém, ktorého zdrojový kód bol vo¾ne dostupný.', '2007-03-20');
INSERT INTO `expl` VALUES (2, 'Unix', 'Jeden z najlepších operaèných systémov svojej doby. Je vyvynutý spoloènos?ou [farba=hneda]Bell Labs[/farba].[n]Jeho hlavnou nevýhodov bola jeho vysoká cena.[n]Unix sa vo ve¾kej miere používa dodnes.', '2007-03-20');
INSERT INTO `expl` VALUES (3, 'Andrew S. Tanenbaum', 'Profesor poèitaèových vied na univerzite Vrije (Amsterdam). Je tvorcom operaèného systému [farba=cervena]MINIX[/farba], ktorý vytvoril na študijné úèely. [n]Viac na... ', '2007-03-20');
INSERT INTO `expl` VALUES (4, 'Linus Torvalds', '[farba=maroon]Linus Benedict Torvalds [/farba][n]\r\nOtec operacného systému LINUX', '2007-03-20');
INSERT INTO `expl` VALUES (5, 'GNU', 'GNU znamena GNU not Unix', '2007-03-20');
INSERT INTO `expl` VALUES (6, 'Richard Stallman', 'Ontec GNU projektu', '2007-03-20');
INSERT INTO `expl` VALUES (7, 'Artificial Intelligence Laboratory', 'MIT Artificial Intelligence Laboratory bolo vývojové stredisko na Massachusettskom Technologickom Inštitúte (Massachusetts Institute of Technology  MIT ), ktorý sa stal jedným z najrozhodujúcejším a najlepším strediskom oh¾adom vývoja umelej inteligencie (AI) a robotiky. Výskum umelej inteligencie sa na MIT zaèal v roku 1959. ', '2007-03-20');
INSERT INTO `expl` VALUES (8, 'Linusov e-mail pre užívate¾ov Minixu', 'From: torvalds@klaava.Helsinki.FI (Linus Benedict Torvalds)[n]\r\nNewsgroups: comp.os.minix[n]\r\nSubject: What would you like to see most in minix?[n]\r\nSummary: small poll for my new operating system[n]\r\nMessage-ID: <1991Aug25.205708.9541@klaava.Helsinki.FI>[n]\r\nDate: 25 Aug 91 20:57:08 GMT[n]\r\nOrganization: University of Helsinki [n]\r\n[n][n]\r\nHello everybody out there using minix -\r\nI''m doing a (free) operating system (just a hobby, won''t be big and\r\nprofessional like gnu) for 386(486) AT clones. This has been brewing\r\nsince april, and is starting to get ready.I''d like any feedback on\r\nthings people like/dislike in minix, as my OS resembles it somewhat\r\n(same physical layout of the file-system(due to practical reasons)\r\namong other things). I''ve currently ported bash(1.08) and gcc(1.40),and\r\nthings seem to work.This implies that I''ll get something practical within a\r\nfew months, andI''d like to know what features most people would want. Any\r\nsuggestions are welcome, but I won''t promise I''ll implement them :-)\r\nLinus (torvalds@kruuna.helsinki.fi)[n]\r\nPS. Yes - it''s free of any minix code, and it has a multi-threaded fs.\r\nIt is NOT protable (uses 386 task switching etc), and it probably never\r\nwill support anything other than AT-harddisks, as that''s\r\nall I have :-(.', '2007-03-20');
INSERT INTO `expl` VALUES (9, ' Linusová správa o linuxe 0.02', 'From: torvalds@klaava.Helsinki.FI (Linus Benedict Torvalds)[n]\r\nNewsgroups: comp.os.minix[n]\r\nSubject: Free minix-like kernel sources for 386-AT[n]\r\nMessage-ID: <1991Oct5.054106.4647@klaava.Helsinki.FI>[n]\r\nDate: 5 Oct 91 05:41:06 GMT[n]\r\nOrganization: University of Helsinki[n][n]\r\nDo you pine for the nice days of minix-1.1, when men were men and wrote their own device drivers?\r\nAre you without a nice project and just dying to cut your teeth on a OS you can try to modify for your\r\nneeds? Are you finding it frustrating when everything works on minix? No more all-nighters to get a nifty program working? Then this post might be just for you :-)\r\nAs I mentioned a month(?)ago, I''m working on a free version of a minix-lookalike for AT-386 computers. It has\r\nfinally reached the stage where it''s even usable (though may not be depending on\r\nwhat you want), and I am willing to put out the sources for wider distribution. It is  just version 0.02 (+1 (very\r\nsmall) patch already), but I''ve successfully run bash/gcc/gnu-make/gnu-sed/compress etc under it.\r\nSources for this pet project of mine can be found at nic.funet.fi (128.214.6.100) in the directory /pub/OS/Linux.\r\nThe directory also contains some README-file and a couple of binaries to work under linux\r\n(bash, update and gcc, what more can you ask for :-). Full kernel source is provided, as no minix code has been\r\nused. Library sources are only partially free, so that cannot be distributed currently. The system is able to compile\r\n"as-is" and has been known to work. Heh. Sources to the binaries (bash and gcc) can be found at the\r\nsame place in /pub/gnu.', '2007-03-20');
INSERT INTO `expl` VALUES (10, 'Andrew Tanenbaum VS. Linus Torvalds', '"I still maintain the point that designing a monolithic kernel in 1991 is a fundamental error. Be thankful you are not my student. You would not get a high grade for such a design :-)" \r\n(Andrew Tanenbaum to Linus Torvalds)', '2007-03-20');
INSERT INTO `expl` VALUES (11, 'Tanenbaumová správa pre Linusa', 'I still maintain the point that designing a monolithic kernel in 1991 is a fundamental error. Be thankful you are not my student. You would not get a high grade for such a design :-)" \r\n(Andrew Tanenbaum to Linus Torvalds)\r\n', '2007-03-20');
INSERT INTO `expl` VALUES (12, 'Linusova správa Tanenbaumovi', 'Your job is being a professor and researcher: That''s one hell of a good excuse for some of the brain-damages of minix. \r\n(Linus Torvalds to Andrew Tanenbaum)\r\n', '2007-03-20');
INSERT INTO `expl` VALUES (14, 'Hacker', 'Pod pojmom [b]hacker[/b] sa [farba=cervena]nerozumje[/farba] osoba ktorá sa nabúra do bezpeènosti za úèelom trestného èinu. Tento pojem si zamenili  dnešné média s pojmom [b]cracker[/b].[n]Hacker je osoba ktorá vylepšuje (hackuje) systém s dobrým úmyslom.', '2007-03-20');
INSERT INTO `expl` VALUES (15, 'Slobodný software', 'Slobodný software [farba=cervena]free software[/farba] je software ktorý umožnuje užívate¾ovi:[n]\r\n-spúš?a? program za akýmkolvek úèelom.[n]\r\n-modifikovat program tak, aby vyhovoval vaším potrebám. (Aby ste túto slobodu mohli realizova? v praxi, musíte ma? prístup ku zdrojovému kódu)[n]\r\n-redistribuovat kópie a to zadarmo, alebo za poplatok.\r\ndistribuova? modifikované verzie programu[n][n]\r\nSlobodný software nijak nesúvisi s cenou ', '2007-03-20');
INSERT INTO `expl` VALUES (16, 'GPL', 'Licencia GPL (General Public Licence) ktorá zaistovala, že autor musí k programu spristupni? aj zdrojové kódy. Ak bol software upravený, musí by? naïalej šírený pod GPL.', '2007-03-20');
INSERT INTO `expl` VALUES (17, 'Softlanding Linux System', 'Softlanding Linux System (SLS) bola jedna z ranných distribúcií linuxu. Autor Peter MacDonald ju zverejnil v polovici roka 1992. \r\nSLS bola najpopularnejšia distribúcia svojej doby a dominovala na trhu. Osudne jej bolo rozhodnutie vyvojárov zameni? pôvodný Unix formát súborov [b]a.out[/b] na vtedy nepopulárny [b]ELF[/b]. \r\n[n][n]\r\nPosledné SLS obsahovalo: jadro, gcc i g++, gdb, emacs, kermit, sc, manual page, groff, elvis, elm, mail, uucp, zip, zoo, lh, X Window System, programovacie knižnice, písma a hry (spider, tetris, xvier, chess, othello, xeyes)', '2007-03-20');
INSERT INTO `expl` VALUES (18, 'Unix-like', 'Operaèné systémy, ktoré sa snažia by? èo najpodobnejšie operaènému systému [b]Unix[/b].', '2007-03-20');
INSERT INTO `expl` VALUES (19, 'The Free Software Foundation', 'Organizácia založená Richardom Stallmanom na podporu slobodného softwaru', '2007-03-20');
INSERT INTO `expl` VALUES (20, 'HURD', 'jadro vyvíjane GNU programátormi. ', '2007-03-20');
INSERT INTO `expl` VALUES (21, 'BSD', 'BSD', '2007-03-20');
INSERT INTO `expl` VALUES (22, 'KDE', 'K des....', '2007-03-20');
INSERT INTO `expl` VALUES (23, 'Zak¾adate¾ské  dokumenty Debianu', '[farba=hneda][stred]EN: Foundational documents of Debian[/stred][/farba]\r\n\r\n1 [farba=modra]Debian Social Contract[/farba]- definuje hlavné princípy projektu Debian, ako i spôsob riadenia organizácie a pracovníkov\r\n2 [farba=modra]Debian Free Software Guidelines[/farba] definuje kritéria [farba=oranzova]free softwaru[/farba] a že software je pristupný v distribúcii tak ako to popisuje predchazajúci dokument (formalne je suèastou predchazajuceho dokumentu). \r\n\r\n3[farba=modra]The Debian Constitution[/farba] Popisuje fungovanie organizacie pre marketing.', '2007-03-20');

-- --------------------------------------------------------

-- 
-- Štruktúra tabuľky pre tabuľku `heslo`
-- 

CREATE TABLE `heslo` (
  `id` int(4) NOT NULL auto_increment,
  `pass` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Sťahujem dáta pre tabuľku `heslo`
-- 

INSERT INTO `heslo` VALUES (1, '47bce5c74f589f4867dbd57e9ca9f808');

-- --------------------------------------------------------

-- 
-- Štruktúra tabuľky pre tabuľku `nastavenia`
-- 

CREATE TABLE `nastavenia` (
  `id` int(11) NOT NULL auto_increment,
  `stm` int(11) NOT NULL default '0',
  `vpo` int(11) NOT NULL default '0',
  `vlo` int(11) NOT NULL default '0',
  `mmlp` int(11) NOT NULL default '0',
  `mmm` int(11) NOT NULL default '0',
  `mmlam` int(11) NOT NULL default '0',
  `form_w` int(11) NOT NULL default '0',
  `textarea_w` int(11) NOT NULL default '0',
  `textarea_h` int(11) NOT NULL default '0',
  `v_s` int(11) NOT NULL default '0',
  `rnt` int(11) NOT NULL default '0',
  `rntpc` int(11) NOT NULL default '0',
  `popupv` int(11) NOT NULL default '0',
  `popups` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- 
-- Sťahujem dáta pre tabuľku `nastavenia`
-- 

INSERT INTO `nastavenia` VALUES (1, 180, 10, 5, 20, 5, 10, 50, 80, 30, 10, 10, 5, 250, 360);
INSERT INTO `nastavenia` VALUES (2, 180, 10, 5, 25, 5, 10, 50, 80, 30, 10, 10, 5, 250, 360);

-- --------------------------------------------------------

-- 
-- Štruktúra tabuľky pre tabuľku `obrazok`
-- 

CREATE TABLE `obrazok` (
  `id` int(11) NOT NULL auto_increment,
  `popis` varchar(255) NOT NULL default '',
  `pov_sirka` int(5) NOT NULL default '0',
  `pov_vyska` int(5) NOT NULL default '0',
  `datum` date NOT NULL default '0000-00-00',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

-- 
-- Sťahujem dáta pre tabuľku `obrazok`
-- 

INSERT INTO `obrazok` VALUES (1, 'Andrew S. Tanenbaum', 170, 239, '2007-03-20');
INSERT INTO `obrazok` VALUES (3, 'Andrew S. Tanenbaum', 250, 188, '2007-03-20');
INSERT INTO `obrazok` VALUES (4, 'Richard Stallman', 242, 241, '2007-03-20');
INSERT INTO `obrazok` VALUES (5, 'Linus Torvalds', 200, 307, '2007-03-20');
INSERT INTO `obrazok` VALUES (6, 'Richard Stallman', 299, 299, '2007-03-20');
INSERT INTO `obrazok` VALUES (8, 'Logo GNU', 180, 170, '2007-03-20');
INSERT INTO `obrazok` VALUES (10, 'Patrick Volkerding', 400, 300, '2007-03-20');
INSERT INTO `obrazok` VALUES (11, 'Slackware tux', 200, 236, '2007-03-20');
INSERT INTO `obrazok` VALUES (12, 'Ian Murdock', 400, 267, '2007-03-20');
INSERT INTO `obrazok` VALUES (13, 'Tux - Logo linuxu', 250, 302, '2007-03-20');

-- --------------------------------------------------------

-- 
-- Štruktúra tabuľky pre tabuľku `profil`
-- 

CREATE TABLE `profil` (
  `id` mediumint(9) NOT NULL auto_increment,
  `user` varchar(255) NOT NULL default '',
  `real_name` varchar(255) NOT NULL default '',
  `real_priezv` varchar(255) NOT NULL default '',
  `email` varchar(255) NOT NULL default '',
  `nieco_o` varchar(255) NOT NULL default '',
  `zverej_email` tinyint(4) NOT NULL default '0',
  `prava` tinyint(4) NOT NULL default '0',
  `id_nastavenia` int(11) NOT NULL default '0',
  `is_active` tinyint(4) NOT NULL default '0',
  `datum` date NOT NULL default '0000-00-00',
  `id_pass` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Sťahujem dáta pre tabuľku `profil`
-- 

INSERT INTO `profil` VALUES (1, 'admin', 'Tomas', 'Valent', 'historialinuxu@gmail.com', 'admin :)', 1, 5, 2, 1, '2007-03-19', 1);

-- --------------------------------------------------------

-- 
-- Štruktúra tabuľky pre tabuľku `sekcia`
-- 

CREATE TABLE `sekcia` (
  `id` int(11) NOT NULL auto_increment,
  `nazov` varchar(255) NOT NULL default '',
  `vysvetlivka` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- 
-- Sťahujem dáta pre tabuľku `sekcia`
-- 

INSERT INTO `sekcia` VALUES (1, 'História Linuxu', 'Sekcia zaoberajúca sa históriou a vývojom OS Linux');
INSERT INTO `sekcia` VALUES (2, 'GNU a GPL', 'Historia projektov GNU');
INSERT INTO `sekcia` VALUES (3, 'Velikáni', 'Známe osobnosti GNU, Linuxu...');
INSERT INTO `sekcia` VALUES (4, 'Distribúcie', 'Svetoznáme distribúcie a ich vývoj');

-- --------------------------------------------------------

-- 
-- Štruktúra tabuľky pre tabuľku `sekcia_clanok`
-- 

CREATE TABLE `sekcia_clanok` (
  `id_clanok` int(11) NOT NULL default '0',
  `id_sekcia` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id_sekcia`,`id_clanok`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Sťahujem dáta pre tabuľku `sekcia_clanok`
-- 

INSERT INTO `sekcia_clanok` VALUES (1, 1);
INSERT INTO `sekcia_clanok` VALUES (2, 1);
INSERT INTO `sekcia_clanok` VALUES (3, 2);
INSERT INTO `sekcia_clanok` VALUES (4, 4);
INSERT INTO `sekcia_clanok` VALUES (5, 4);

-- --------------------------------------------------------

-- 
-- Štruktúra tabuľky pre tabuľku `testuj_s`
-- 

CREATE TABLE `testuj_s` (
  `id` int(11) NOT NULL auto_increment,
  `clanazov` varchar(255) NOT NULL default '',
  `clatext` text NOT NULL,
  `cladatum` date NOT NULL default '0000-00-00',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Sťahujem dáta pre tabuľku `testuj_s`
-- 

